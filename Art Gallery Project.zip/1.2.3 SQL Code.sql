-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2023 at 03:58 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertArtwork` (IN `artitle` VARCHAR(255), IN `aname` VARCHAR(255), IN `price` DECIMAL(10,2))   BEGIN
    INSERT INTO artwork (ARTITLE, ANAME, PRICE) VALUES (artitle, aname, price);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `artist`
--

CREATE TABLE `artist` (
  `AID` int(20) NOT NULL,
  `ANAME` varchar(200) NOT NULL,
  `Contact` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artist`
--

INSERT INTO `artist` (`AID`, `ANAME`, `Contact`) VALUES
(0, 'ali', 357637),
(123, 'ARijit', 378459848),
(6356, 'hari', 8768783),
(0, 'hbh', 8768783),
(3465, 'sdgrdg', 7644);

-- --------------------------------------------------------

--
-- Table structure for table `artwork`
--

CREATE TABLE `artwork` (
  `ARID` int(20) NOT NULL,
  `ARTITLE` varchar(50) NOT NULL,
  `PRICE` int(20) NOT NULL,
  `ANAME` varchar(50) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artwork`
--

INSERT INTO `artwork` (`ARID`, `ARTITLE`, `PRICE`, `ANAME`, `last_updated`) VALUES
(45, 'Channa Mereya', 2500, 'ARijit', '2023-10-26 00:53:40'),
(3242, 'gerg', 243, 'hbh', '2023-10-26 00:53:40'),
(0, 'ssa', 323, 'ali', '2023-10-26 00:53:40'),
(23, 'sun', 2234, 'sdgrdg', '2023-10-26 00:53:40'),
(1111, 'whfb', 432432, 'hbh', '2023-10-26 00:53:40');

--
-- Triggers `artwork`
--
DELIMITER $$
CREATE TRIGGER `artwork_insert_trigger` BEFORE INSERT ON `artwork` FOR EACH ROW BEGIN
    SET NEW.last_updated = NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CNAME` varchar(200) NOT NULL,
  `CONTACT` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CNAME`, `CONTACT`) VALUES
('john', 3453453);

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

CREATE TABLE `owner` (
  `O_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `owner`
--

INSERT INTO `owner` (`O_name`) VALUES
('ria');

-- --------------------------------------------------------

--
-- Table structure for table `sales_records`
--

CREATE TABLE `sales_records` (
  `PAYMENT` varchar(200) NOT NULL,
  `DATE` date NOT NULL,
  `ARTITLE` varchar(20) NOT NULL,
  `CNAME` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_records`
--

INSERT INTO `sales_records` (`PAYMENT`, `DATE`, `ARTITLE`, `CNAME`) VALUES
('online', '2023-10-22', 'Channa Mereya', 'john'),
('cash', '2023-10-23', 'sun', 'john');

-- --------------------------------------------------------

--
-- Table structure for table `shop_staff`
--

CREATE TABLE `shop_staff` (
  `STAFF` enum('SA','SO') NOT NULL,
  `SID` int(20) NOT NULL,
  `SNAME` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shop_staff`
--

INSERT INTO `shop_staff` (`STAFF`, `SID`, `SNAME`) VALUES
('SO', 22, 'ria');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `S_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artist`
--
ALTER TABLE `artist`
  ADD PRIMARY KEY (`ANAME`);

--
-- Indexes for table `artwork`
--
ALTER TABLE `artwork`
  ADD PRIMARY KEY (`ARTITLE`),
  ADD KEY `ANAME` (`ANAME`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CNAME`);

--
-- Indexes for table `owner`
--
ALTER TABLE `owner`
  ADD PRIMARY KEY (`O_name`);

--
-- Indexes for table `sales_records`
--
ALTER TABLE `sales_records`
  ADD KEY `ARTITLE` (`ARTITLE`),
  ADD KEY `CNAME` (`CNAME`);

--
-- Indexes for table `shop_staff`
--
ALTER TABLE `shop_staff`
  ADD PRIMARY KEY (`SNAME`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`S_name`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `artwork`
--
ALTER TABLE `artwork`
  ADD CONSTRAINT `ANAME_fk` FOREIGN KEY (`ANAME`) REFERENCES `artist` (`ANAME`);

--
-- Constraints for table `owner`
--
ALTER TABLE `owner`
  ADD CONSTRAINT `owner_ibfk_1` FOREIGN KEY (`O_name`) REFERENCES `shop_staff` (`SNAME`);

--
-- Constraints for table `sales_records`
--
ALTER TABLE `sales_records`
  ADD CONSTRAINT `sales_records_ibfk_1` FOREIGN KEY (`ARTITLE`) REFERENCES `artwork` (`ARTITLE`),
  ADD CONSTRAINT `sales_records_ibfk_2` FOREIGN KEY (`CNAME`) REFERENCES `customer` (`CNAME`);

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`S_name`) REFERENCES `shop_staff` (`SNAME`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
