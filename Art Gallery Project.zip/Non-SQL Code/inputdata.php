<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

$connection = new mysqli($servername, $username, $password, $database);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
if (isset($_POST["submit_artist"])) {
        // Handle Artist form submission
        $arid = $_POST["arid"];
        $aname = $_POST["aname"];
        $contact = $_POST["contact"];

        $sql = "INSERT INTO artist (ARID, ANAME, Contact) VALUES ('$arid', '$aname', '$contact')";

        if ($connection->query($sql) === TRUE) {
            echo "Artist record inserted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["submit_artwork"])) {
        // Handle Artwork form submission
        $arid = $_POST["arid"];
        $artitle = $_POST["artitle"];
        $aname = $_POST["aname"];
        $price = $_POST["price"];

        $sql = "INSERT INTO artwork (ARID, ARTITLE, ANAME, PRICE) VALUES ('$arid', '$artitle', '$aname', $price)";

        if ($connection->query($sql) === TRUE) {
            echo "Artwork record inserted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }

    }

    if (isset($_POST["submit_customer"])) {
        // Handle Customer form submission
        $cname = $_POST["cname"];
        $contact = $_POST["contact"];

        $sql = "INSERT INTO customer (CNAME, CONTACT) VALUES ('$cname', '$contact')";

        if ($connection->query($sql) === TRUE) {
            echo "Customer record inserted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }

    if (isset($_POST["submit_sales_records"])) {
        // Handle Sales Records form submission
        $payment = $_POST["payment"];
        $date = $_POST["date"];
        $artitle = $_POST["artitle"];
        $cname = $_POST["cname"];
        $price = $_POST["price"];

        $sql = "INSERT INTO sales_records (PAYMENT, DATE, ARTITLE, CNAME) VALUES ('$payment', '$date', '$artitle', '$cname')";
        if ($connection->query($sql) === TRUE) {
            echo "Sales Record inserted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }
if (isset($_POST["submit_shop_staff"])) {
        // Handle Shop Staff form submission
        $staff = $_POST["staff"];
        $sid = $_POST["sid"];
        $sname = $_POST["sname"];

        $sql = "INSERT INTO shop_staff (STAFF, SID, SNAME) VALUES ('$staff', '$sid', '$sname')";
        if ($connection->query($sql) === TRUE) {
            echo "Shop Staff record inserted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }   
    

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["submit_owner"])) {
        // Handle Owner form submission
        $o_name = $_POST["o_name"];

        $sql = "INSERT INTO owner (O_name) VALUES ('$o_name')";

        if ($connection->query($sql) === TRUE) {
            echo "Owner record inserted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }

    if (isset($_POST["submit_staff"])) {
        // Handle Staff form submission
        $s_name = $_POST["s_name"];

        $sql = "INSERT INTO staff (S_name) VALUES ('$s_name')";

        if ($connection->query($sql) === TRUE) {
            echo "Staff record inserted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }
}

$connection->close();
?>
 


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Insert Data</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body style="margin: 50px;">
    <div class="container">
        <h1>Insert Artist</h1>
        <form method="post">
            <div class="form-group">
                <label for="arid">ARID:</label>
                <input type="text" class="form-control" id="arid" name="arid">
            </div>
            <div class="form-group">
                <label for="aname">Artist Name:</label>
                <input type="text" class="form-control" id="aname" name="aname">
            </div>
            <div class="form-group">
                <label for="contact">Contact:</label>
                <input type="text" class="form-control" id="contact" name="contact">
            </div>
            <button type="submit" class="btn btn-primary" name="submit_artist">Submit Artist</button>
        </form>
        <h1>Insert Artwork</h1>
        <form method="post">
            <div class="form-group">
                <label for="arid">ARID:</label>
                <input type="text" class="form-control" id="arid" name="arid">
            </div>
            <div class="form-group">
                <label for="artitle">Art Title:</label>
                <input type="text" class="form-control" id="artitle" name="artitle">
            </div>
            <div class="form-group">
                <label for="aname">Artist Name:</label>
                <input type="text" class="form-control" id="aname" name="aname">
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" class="form-control" id="price" name="price">
            </div>
            <button type="submit" class="btn btn-primary" name="submit_artwork">Submit Artwork</button>
        </form>

        

        <h1>Insert Customer</h1>
        <form method="post">
            <div class="form-group">
                <label for="cname">Customer Name:</label>
                <input type="text" class="form-control" id="cname" name="cname">
            </div>
            <div class="form-group">
                <label for="contact">Contact:</label>
                <input type="text" class="form-control" id="contact" name="contact">
            </div>
            <button type="submit" class="btn btn-primary" name="submit_customer">Submit Customer</button>
        </form>

        <h1>Insert Sales Record</h1>
        <form method="post">
            <div class="form-group">
                <label for="payment">Payment:</label>
                <input type="text" class="form-control" id="payment" name="payment">
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" class="form-control" id="date" name="date">
            </div>
            <div class="form-group">
                <label for="artitle">Art Title:</label>
                <input type="text" class="form-control" id="artitle" name="artitle">
            </div>
            <div class="form-group">
                <label for="cname">Customer Name:</label>
                <input type="text" class="form-control" id="cname" name="cname">
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" class="form-control" id="price" name="price">
            </div>
            <button type="submit" class="btn btn-primary" name="submit_sales_records">Submit Sales Record</button>
        </form>
        <h1>Insert Shop Staff(IF NEW STAFF JOINED)</h1>
        <form method="post">
            <div class="form-group">
                <label for="staff">Staff:</label>
                <select class="form-control" id="staff" name="staff">
                    <option value="SO">Sales Officer (SO)</option>
                    <option value="SA">Sales Associate (SA)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="sid">SID:</label>
                <input type="text" class="form-control" id="sid" name="sid">
            </div>
            <div class="form-group">
                <label for="sname">Staff Name:</label>
                <input type="text" class="form-control" id="sname" name="sname">
            </div>
            <button type="submit" class="btn btn-primary" name="submit_shop_staff">Submit Shop Staff</button>
        </form>
    </div>
    <div class="container">
        <h1>Insert Owner</h1>
        <form method="post">
            <div class="form-group">
                <label for="o_name">Owner Name:</label>
                <input type="text" class="form-control" id="o_name" name="o_name">
            </div>
            <button type="submit" class="btn btn-primary" name="submit_owner">Submit Owner</button>
        </form>

        <h1>Insert Staff</h1>
        <form method="post">
            <div class="form-group">
                <label for="s_name">Staff Name:</label>
                <input type="text" class="form-control" id="s_name" name="s_name">
            </div>
            <button type="submit" class="btn btn-primary" name="submit_staff">Submit Staff</button>
        </form>
    </div>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
</body>
</html>
