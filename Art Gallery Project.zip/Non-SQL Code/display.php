<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Art Gallery</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        body {
            margin: 50px;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        
        .nav-tabs {
            background-color: #333;
        }
        
        .nav-tabs .nav-item a {
            color: #fff;
        }
        
        .tab-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }
        
        .table {
            border: 1px solid #ccc;
            border-collapse: collapse;
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .table th, .table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        
        .table th {
            background-color: #333;
            color: #fff;
        }
    </style>
</head>
<body style="margin: 50px;">
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link active" id="artworks-tab" data-toggle="tab" href="#artworks" role="tab" aria-controls="artworks" aria-selected="true">Artworks</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class a="nav-link" id="artists-tab" data-toggle="tab" href="#artists" role="tab" aria-controls="artists" aria-selected="false">Artists</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="customers-tab" data-toggle="tab" href="#customers" role="tab" aria-controls="customers" aria-selected="false">Customers</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="sales-records-tab" data-toggle="tab" href="#sales-records" role="tab" aria-controls="sales-records" aria-selected="false">Sales Records</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="shop-staff-tab" data-toggle="tab" href="#shop-staff" role="tab" aria-controls="shop-staff" aria-selected="false">Shop Staff</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="Owners-tab" data-toggle="tab" href="#Owners" role="tab" aria-controls="Owners" aria-selected="false">Owners</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="staff-tab" data-toggle="tab" href="#staff" role="tab" aria-controls="staff" aria-selected="false">Staff</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="correlated-subquery-tab" data-toggle="tab" href="#correlated-subquery" role="tab" aria-controls="correlated-subquery" aria-selected="false">Display of Artwork</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="artwork-view-tab" data-toggle="tab" href="#artwork-view" role="tab" aria-controls="artwork-view" aria-selected="false">Artwork View</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="view-tab" data-toggle="tab" href="#view" role="tab" aria-controls="view" aria-selected="false">View by ALL</a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="artworks" role="tabpanel" aria-labelledby="artworks-tab">
            <h1>List Of Artworks</h1><br>
            <table class="table">
                <tr>
                    <th>ARID</th>
                    <th>ARTITLE</th>
                    <th>Total Price</th>
                    <th>ANAME</th>
                    <th>Last Updated</th> <!-- New column header -->
                </tr>
                <tbody>
                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $database = "project";
                    $connection = new mysqli($servername, $username, $password, $database);
                    $sql = "SELECT ARID, ARTITLE, ANAME, SUM(PRICE) AS TotalPrice, last_updated FROM artwork GROUP BY ANAME, ARID, ARTITLE";
                    $result = $connection->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>" . $row["ARID"] . "</td>
                            <td>" . $row["ARTITLE"] . "</td>
                            <td>" . $row["TotalPrice"] . "</td>
                            <td>" . $row["ANAME"] . "</td>
                            <td>" . $row["last_updated"] . "</td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
    <script>
        // JavaScript to handle tab navigation
        $('#myTab a').on('click', function (e) {
            e.preventDefault();
            $(this).tab('show');
        });
    </script>
    
<div class="tab-pane fade" id="artists" role="tabpanel" aria-labelledby="artists-tab">
    <h1>List Of Artists</h1><br>
    <table class="table">
        <tr>
            <th>AID</th>
            <th>ANAME</th>
            <th>Contact</th>
            <th>Total Price of Artworks</th>
        </tr>
        <tbody>
            <?php
            $sql = "SELECT a.AID, a.ANAME, a.Contact,
                (SELECT SUM(artwork.PRICE) 
                FROM artwork 
                WHERE artwork.ANAME = a.ANAME) AS TotalArtworkPrice
                FROM artist a";
            $result = $connection->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["AID"] . "</td>
                    <td>" . $row["ANAME"] . "</td>
                    <td>" . $row["Contact"] . "</td>
                    <td>" . $row["TotalArtworkPrice"] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<div class="tab-pane fade" id="customers" role="tabpanel" aria-labelledby="customers-tab">
    <h1>List Of Customers</h1><br>
    <table class="table">
        <tr>
            <th>CNAME</th>
            <th>CONTACT</th>
        </tr>
        <tbody>
            <?php
            $sql = "SELECT * FROM customer";
            $result = $connection->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["CNAME"] . "</td>
                    <td>" . $row["CONTACT"] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<div class="tab-pane fade" id="sales-records" role="tabpanel" aria-labelledby="sales-records-tab">
    <h1>List Of Sales Records</h1><br>
    <table class="table">
        <tr>
            <th>PAYMENT</th>
            <th>DATE</th>
            <th>ARTITLE</th>
            <th>CNAME</th>
            <th>PRICE</th>
        </tr>
        <tbody>
            <?php
            $sql = "SELECT sr.PAYMENT, sr.DATE, sr.ARTITLE, sr.CNAME, a.PRICE FROM sales_records sr INNER JOIN artwork a ON sr.ARTITLE = a.ARTITLE";
            $result = $connection->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["PAYMENT"] . "</td>
                    <td>" . $row["DATE"] . "</td>
                    <td>" . $row["ARTITLE"] . "</td>
                    <td>" . $row["CNAME"] . "</td>
                    <td>" . $row["PRICE"] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<div class="tab-pane fade" id="shop-staff" role="tabpanel" aria-labelledby="shop-staff-tab">
    <h1>List Of Shop Staff</h1><br>
    <table class="table">
        <tr>
            <th>STAFF</th>
            <th>SID</th>
            <th>SNAME</th>
        </tr>
        <tbody>
            <?php
            $sql = "SELECT * FROM shop_staff";
            $result = $connection->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["STAFF"] . "</td>
                    <td>" . $row["SID"] . "</td>
                    <td>" . $row["SNAME"] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
<div class="tab-pane fade" id="Owners" role="tabpanel" aria-labelledby="Owners-tab">
    <h1>List Of Owners</h1><br>
    <table class="table">
        <tr>
            <th>Owner Name</th>
        </tr>
        <tbody>
            <?php
            $sql = "SELECT * FROM owner";
            $result = $connection->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["O_name"] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
<div class="tab-pane fade" id="staff" role="tabpanel" aria-labelledby="staff-tab">
    <h1>List Of Staff</h1><br>
    <table class="table">
        <tr>
            <th>Staff Name</th>
        </tr>
        <tbody>
            <?php
            $sql = "SELECT * FROM staff";
            $result = $connection->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["S_name"] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<div class="tab-pane fade" id="correlated-subquery" role="tabpanel" aria-labelledby="correlated-subquery-tab">
    <h1>DIsplay of Artwork(Using Correlated)</h1><br>
    <table class="table">
        <tr>
            <th>ARTITLE</th>
            <th>ANAME</th>
        </tr>
        <tbody>
            <?php
            $sql = "SELECT ARTITLE, ANAME FROM artwork a
                    WHERE ARTITLE IN (SELECT ARTITLE FROM artist b WHERE a.ANAME = b.ANAME)";
            $result = $connection->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["ARTITLE"] . "</td>
                    <td>" . $row["ANAME"] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
<script>
    // JavaScript to handle tab navigation
    $('#myTab a').on('click', function (e) {
        e.preventDefault();
        $(this).tab('show');
    });
</script>
<div class="tab-pane fade" id="artwork-view" role="tabpanel" aria-labelledby="artwork-view-tab">
            <h1>Artwork View</h1><br>
            <table class="table">
                <tr>
                    <th>ARID</th>
                    <th>ARTITLE</th>
                    <th>ANAME</th>
                </tr>
                <tbody>
                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $database = "project";
                    $connection = new mysqli($servername, $username, $password, $database);
                    
                    // Assuming you have a view named "ArtworkView"
                    $sql = "SELECT * FROM Artwork";
                    $result = $connection->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>" . $row["ARID"] . "</td>
                            <td>" . $row["ARTITLE"] . "</td>
                            <td>" . $row["ANAME"] . "</td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="view" role="tabpanel" aria-labelledby="view-tab">
    <h1>Artwork View(USing ALL)</h1><br>
    <table class="table">
        <tr>
            <th>ARID</th>
            <th>ARTITLE</th>
            <th>ANAME</th>
        </tr>
        <tbody>
            <?php
            $sql = "SELECT ARID, ARTITLE, ANAME
                    FROM Artwork
                    WHERE PRICE <= ALL (SELECT PRICE FROM Artwork)";
            $result = $connection->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["ARID"] . "</td>
                    <td>" . $row["ARTITLE"] . "</td>
                    <td>" . $row["ANAME"] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
</body>
</html>
