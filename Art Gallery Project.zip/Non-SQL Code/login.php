<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

$connection = new mysqli($servername, $username, $password, $database);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["login"])) {
        $staff_id = $_POST["staff_id"];

        // Check if the staff ID exists in the shop_staff table
        $sql = "SELECT SID FROM shop_staff WHERE SID = '$staff_id'";
        $result = $connection->query($sql);

        if ($result->num_rows > 0) {
            // Valid staff ID, redirect to the input page
            header("Location: artwork.php"); // Replace 'input_page.php' with the actual filename
            exit();
        } else {
            echo "Invalid Staff ID";
        }
    }
}

$connection->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body style="margin: 50px;">
    <div class="container">
        <h1>Login</h1>
        <form method="post">
            <div class="form-group">
                <label for="staff_id">Staff ID:</label>
                <input type="text" class="form-control" id="staff_id" name="staff_id">
            </div>
            <button type="submit" class="btn btn-primary" name="login">Login</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
</body>
</html>
