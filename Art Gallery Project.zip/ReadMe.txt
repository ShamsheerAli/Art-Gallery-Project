To do the assignment 2, I installed the Apache(XAMPP) server. And in that application I started the 
Apache server and the MySQL. To install and run the XAMPP application the system. The system should 
be in 64 bit panel. 

After starting the servers the phpMyAdmin will be opened and the database is created in it.

I created the database of enitites: Artwork, Artist, Customer, Sales Associate, Staff, Owner, and Shop 
Staff.

And those entites have their own attributes and Primary keys and also foreign keys. 

After that I connected the database to the web page with the help of PHP which is an frontend 
language.

And then after connecting the database successfully I wrote the code to display the database.

And then I created an input web page by which I can insert the values into the tables from the webpage 
itself. And also a login page.

TO RUN MY CODE IN SYSTEM:
1. INSTALL XAMPP
2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.
3."PROJECT"
4. Download the zip file/ download winrar
5. Extract the file and copy "PROJECT" folder
6.Paste inside root directory/ where you install xampp local disk C: drive D: drive E: paste: (for 
xampp/htdocs.
7. Open PHPMyAdmin (http://localhost/phpmyadmin